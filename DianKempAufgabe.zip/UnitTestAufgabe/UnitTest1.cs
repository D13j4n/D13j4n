using System;
using System.Collections.Generic;
using ekRobotics;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestEKRobotics
{
    [TestClass]
    public class ShuntingYardTests
    {
        [TestMethod]
        public void EvaluateEquation_PrecedenceWithMultiply_Seven()
        {
            var interpreter = new ExpressionInterpreter("3+4*2+1-5");
            Assert.AreEqual(7,interpreter.Calculate());
        }

        [TestMethod]
        public void EvaluateEquation_PrecedenceWithBracket_Fifteen()
        {
            var interpreter = new ExpressionInterpreter(("3*(4-2)+9"));
            Assert.AreEqual(15, interpreter.Calculate());
        }

        [TestMethod]
        public void EvaluateEquation_PrecedenceWithMultipleBrackets_MinSeven()
        {
            var interpreter = new ExpressionInterpreter("(5+2)*(3-4)");
            Assert.AreEqual(-7, interpreter.Calculate());
        }

        [TestMethod]
        public void EvaluateEquation_PrecedenceWithMultiplyAndVariable_Seven()
        {
            var values = new Dictionary<Variable, int>();
            var interpreter = new ExpressionInterpreter("3+4*y+1-5");
            values.Add(new Variable('y'),2);
            Assert.AreEqual(7, interpreter.CalculateWith(values));
        }

        [TestMethod]
        public void EvaluateEquation_PrecedenceWithBracketAndVariable_Fifteen()
        {
            var values = new Dictionary<Variable, int>();
            var interpreter = new ExpressionInterpreter("3*(4-y)+9");
            values.Add(new Variable('y'), 2);
            Assert.AreEqual(15, interpreter.CalculateWith(values));
        }

        [TestMethod]
        public void EvaluateEquation_PrecedenceWithMultipleBracketsAndVariable_MinSeven()
        {
            var values = new Dictionary<Variable, int>();
            var interpreter = new ExpressionInterpreter("(5+y)*(3-4)");
            values.Add(new Variable('y'), 2);
            Assert.AreEqual(-7, interpreter.CalculateWith(values));
        }

        [TestMethod]
        public void EvaluateEquation_TestExample_MinSeventeen()
        {
            var values = new Dictionary<Variable, int>();
            var interpreter = new ExpressionInterpreter("3*x + 20- y * (z + 17)");
            values.Add(new Variable('x'), 1);
            values.Add(new Variable('y'), 2); 
            values.Add(new Variable('z'), 3);
            Assert.AreEqual(-17, interpreter.CalculateWith(values));
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void EvaluateEquation_VariableOutsidePrescribedBounds_InvalidOperationException()
        {
            var values = new Dictionary<Variable, int>();
            var interpreter = new ExpressionInterpreter("3+A");
            values.Add(new Variable('A'), 2);
        }
    }
}