﻿using System.Text.RegularExpressions;

namespace ekRobotics;

public class ExpressionInterpreter
{
    public Stack<object> ExpressionStack { get; set; }

    public ExpressionInterpreter(string expressionAsString)
    {
        ExpressionStack = GetReversePolishEquation(expressionAsString);
    }

    public int CalculateWith(Dictionary<Variable, int> valuesOfVariables)
    {
        var evaluator = new EquationEvaluator(valuesOfVariables);
        var result = evaluator.CalculateReversePolish(ExpressionStack);
        return result;
    }

    public int Calculate()
    {
        var evaluator = new EquationEvaluator();
        var result = evaluator.CalculateReversePolish(ExpressionStack);
        return result;
    }

    private Stack<object> GetReversePolishEquation(string equation)
    {
        var outputStack = new Stack<object>();
        var operatorStack = new Stack<char>();
        equation = String.Concat(equation.Where(c => !Char.IsWhiteSpace(c)));
        var regexString = string.Format(@"(?=[{0}])|(?<=[{0}])", string.Join("", Operator.OperandOrder));
        var splitString = Regex.Split(equation, regexString);
        for (int i = 0; i < splitString.Length; i++)
        {
            if (splitString[i] == "") continue;
            int element;
            bool isInt = int.TryParse(splitString[i], out element);

            if (isInt)
            {
                outputStack.Push(element);
            }
            else if (IsOperand(splitString[i]))
            {
                var newOperand = char.Parse(splitString[i]);
                char lastOperand;
                var stackHasOperands = operatorStack.TryPeek(out lastOperand);
                if (stackHasOperands && newOperand == ')')
                {
                    while (!operatorStack.Peek().Equals('('))
                    {
                        outputStack.Push(operatorStack.Peek());
                        operatorStack.Pop();
                    }

                    operatorStack.Pop();
                    continue;
                }

                while (stackHasOperands && IsHigherOrder(lastOperand, newOperand) && lastOperand != '(')
                {
                    outputStack.Push(operatorStack.Pop());
                    stackHasOperands = operatorStack.TryPeek(out lastOperand);
                }

                operatorStack.Push(newOperand);
            }
            else if (IsVariable(splitString[i], out char variable))
            {
                outputStack.Push(new Variable(variable));
            }
            else
            {
                outputStack.Push(element);
            }
        }

        for (int c = operatorStack.Count; c >= 1; c--)
        {
            outputStack.Push(operatorStack.Peek());
            operatorStack.Pop();
        }

        var revStack = new Stack<object>();
        while (outputStack.Count >= 1)
        {
            revStack.Push(outputStack.Pop());
        }

        return revStack;
    }

    private bool IsHigherOrder(char compareOperand, char compareToOperand)
    {
        var isHigherOrder = false;
        try
        {
            isHigherOrder = Operator.PrecedenceList[compareOperand] >= Operator.PrecedenceList[compareToOperand];
        }
        catch (Exception e)
        {
            throw new InvalidOperationException("The given operand cannot be found");
        }

        return isHigherOrder;
    }

    private bool IsOperand(string testVar)
    {
        char operand;
        if (char.TryParse(testVar, out operand) == false)
            return false;
        return Array.FindIndex(Operator.OperandOrder, op => op == operand) != -1;
    }

    private bool IsVariable(string testVar, out char variable)
    {
        // Function that determines whether a given string is a single character and returns the char value by using an output variable
        if (char.TryParse(testVar, out variable) == false)
            return false;
        return true;
    }
}