﻿namespace ekRobotics;

public class Variable
{
    private char _name;

    public Variable(char name)
    {
        if (name<='z' && name>='a')
        {
            _name = name;
        }
        else
        {
            throw new InvalidOperationException("The variable is not within the expected range.");
        }
    }

    public Variable()
    {
        
    }

    public override int GetHashCode()
    {
        return (int)_name;
    }
    public override bool Equals(object obj)
    {
        return Equals(obj as Variable);
    }
    public bool Equals(Variable obj)
    {
        return obj != null && obj._name == this._name;
    }
}