﻿namespace ekRobotics;

public class EquationEvaluator
{
    private Dictionary<Variable, int> _variables;
    private bool _hasDictionary;

    public EquationEvaluator(Dictionary<Variable, int> variables)
    {
        this._variables = variables;
        _hasDictionary = true;
    }

    public EquationEvaluator()
    {
        _hasDictionary = false;
    }
    public int CalculateReversePolish(Stack<object> stack)
    {
        var numberStack = new Stack<int>();

        var stackCount = stack.Count();
        while (stack.Count >= 1)
        {
            if (stack.Peek().GetType().Equals(typeof(char)))
            {
                var num1 = numberStack.Pop();
                var num2 = numberStack.Pop();
                var tempOperator = Operator.OperatorDictionary[(char) stack.Pop()];
                numberStack.Push(tempOperator.Execute(num2, num1));
            }
            else if (stack.Peek().GetType().Equals(new Variable().GetType()))
            {
                try
                {
                    numberStack.Push(_variables[stack.Pop() as Variable]);
                }
                catch (KeyNotFoundException)
                {
                    Console.WriteLine("The variable cannot be found in the dictionary");
                    throw;
                }
            }
            else
            {
                numberStack.Push((int) stack.Pop());
            }
        }

        return numberStack.Pop();
    }
}