﻿namespace ekRobotics;

public class Operator
{
    public static readonly Dictionary<char, Operator> OperatorDictionary = new Dictionary<char, Operator>()
    {
        {'*', new Multiplier()},
        {'+', new Adder()},
        {'-', new Subtractor()},
    };

    public static readonly Dictionary<char, int> PrecedenceList = new Dictionary<char, int>()
    {
        {'(', 5},
        {')', 5},
        {'*', 3},
        {'+', 2},
        {'-', 2},
    };
    public static readonly char[] OperandOrder = new char[] { '(', ')', '^',  '*', '+', '-' };
    public virtual int Execute(int num1, int num2)
    {
        throw new NotImplementedException();
    }
}

public class Multiplier : Operator
{
    public override int Execute(int num1, int num2)
    {
        /*
         * Function that multiplies two given parameters and returns the result as an int
         */
        return num1 * num2;
    }
}

public class Adder : Operator

{
    public override int Execute(int num1, int num2)
    {
        /*
         * Function that adds two given parameters and returns the result as an int
         */
        return num1 + num2;
    }
}

public class Subtractor : Operator

{
    public override int Execute(int num1, int num2)
    {
        /*
         * Function that subtracts num2 from num1 and returns the result as an int
         */
        return num1 - num2;
    }
}